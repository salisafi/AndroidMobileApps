package com.example.salimeh.map524_lab4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;

public class MainActivity extends AppCompatActivity {

        String[] alphabetArray = {"A","B","C","D","E","F","G","H", "I","J","K",
                "L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};

         Integer [] multiply7Array = new Integer[99];

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            ArrayAdapter<String> arrayAdapterCarol = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, alphabetArray);
            ListView leftleListView = findViewById(R.id.leftListView);
            leftleListView.setAdapter(arrayAdapterCarol);


          //  leftleListView.setTextColor(Color.BLUE);

            int total = 0;
            for (int i = 0; i < 99; i++){
                total = total + 7;
                multiply7Array[i] = total;
            }

            ArrayAdapter<Integer> arrayAdapterSecond = new ArrayAdapter<Integer>(this, android.R.layout.simple_gallery_item, multiply7Array);
            GridView rightGidview = findViewById(R.id.rightGidview);
            rightGidview.setAdapter(arrayAdapterSecond);

    }
}
