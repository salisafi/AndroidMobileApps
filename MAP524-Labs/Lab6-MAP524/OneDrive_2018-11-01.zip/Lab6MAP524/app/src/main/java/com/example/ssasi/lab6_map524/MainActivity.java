package com.example.ssasi.lab6_map524;

import android.support.v7.app.AppCompatActivity;
import android.app.AlertDialog;
import android.database.Cursor;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText idET, nameET, markET;

    TextView markTV;

    Button addBTN, viewBTN, findBTN, deleteBTN;

    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        idET = (EditText)findViewById(R.id.idET);
        nameET = (EditText)findViewById(R.id.nameET);
        markET = (EditText)findViewById(R.id.markET);


        markTV = (TextView)findViewById(R.id.markTV);

        String idEntered = idET.getText().toString();
      //  markTV.setText(idEntered);


        addBTN = (Button) findViewById(R.id.addBTN);
        viewBTN = (Button) findViewById(R.id.viewBTN);
        findBTN = (Button) findViewById(R.id.findBTN);
        deleteBTN = (Button) findViewById(R.id.deleteBTN);


        addBTN.setOnClickListener(new View.OnClickListener() {
           @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"add button is clicked", Toast.LENGTH_SHORT).show();
            }



    });

        viewBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "view button is clicked", Toast.LENGTH_SHORT).show();
            }
        });

        findBTN.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view){
                Toast.makeText(getApplicationContext(), "find buton is clicked", Toast.LENGTH_SHORT).show();
            }
        });

        deleteBTN.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view){
                Toast.makeText(getApplicationContext(), "find buton is clicked", Toast.LENGTH_SHORT).show();
            }
        });

            addBTN.setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            boolean isInserted = myDb.insertData(
                                    nameET.getText().toString(),
                                    markET.getText().toString() );
                            if(isInserted == true)
                                Toast.makeText(MainActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(MainActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();
                        }
                    }
            );


        viewBTN.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                        if(res.getCount() == 0) {
                            // show message
                            showMessage("Error","Nothing found");
                          //  Toast.makeText(MainActivity.this,"Error - Nothing found",Toast.LENGTH_LONG).show();
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Id :"+ res.getString(0)+"\n");
                            buffer.append("Name :"+ res.getString(1)+"\n");
                            buffer.append("Marks :"+ res.getString(2)+"\n\n");
                        }

                        // Show all data
                        showMessage("Data",buffer.toString());
                    }
                }
        );



        public void showMessage(String title,String Message){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle(title);
            builder.setMessage(Message);
            builder.show();
        }

// http://www.codebind.com/android-tutorials-and-examples/android-sqlite-tutorial-example/

    }
}
